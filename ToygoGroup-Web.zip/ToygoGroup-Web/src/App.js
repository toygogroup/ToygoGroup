import React from 'react';

// ده المكون الرئيسي (الشكل العام) لتطبيقك
function App() {
  return (
    // هنا بنعمل تصميم للصفحة باستخدام Tailwind CSS عشان تبقى شيك ومتجاوبة
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-blue-500 to-purple-600 p-4">
      <div className="bg-white p-8 rounded-xl shadow-2xl text-center max-w-sm w-full transform transition duration-500 hover:scale-105">
        <h1 className="text-4xl font-bold text-gray-800 mb-4 animate-bounce">
          🚀 أهلًا وسهلًا في تويجو جروب!
        </h1>
        <p className="text-lg text-gray-600 mb-6">
          أول منصة ميتافيرس عربية تعمل بالكامل من المتصفح.
        </p>
        {/* دي صورة هتظهر في الصفحة، جاري استخدام رابط صورة placeholder كمثال */}
        <img 
          src="https://placehold.co/300x200/4e54c8/ffffff?text=Toygo+Group" 
          alt="صورة ميتافيرس تويجو جروب" 
          className="mx-auto rounded-lg shadow-md mb-6"
          // لو الصورة محملتش، هيظهر مكانها صورة تانية عشان الشكل ميتكسرش
          onError={(e) => { e.target.onerror = null; e.target.src = "https://placehold.co/300x200/4e54c8/ffffff?text=Image+Load+Error"; }}
        />
        <p className="text-sm text-gray-500">
          جاري العمل على المنصة وجميع الميزات المثيرة...
        </p>
        <p className="text-sm text-gray-500">
          شكراً لصبركم ودعمكم!
        </p>
      </div>
    </div>
  );
}

export default App;

