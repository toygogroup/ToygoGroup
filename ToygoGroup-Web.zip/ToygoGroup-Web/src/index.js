import React from 'react';
import ReactDOM from 'react-dom';
import App from './App'; // بنستورد (بنجيب) مكون App اللي عملناه

// دي النقطة اللي بيبدأ منها التطبيق بتاعنا يشتغل في المتصفح
ReactDOM.render(
  // React.StrictMode ده بيساعدنا نكتشف أي مشاكل ممكن تحصل في الكود
  <React.StrictMode>
    <App /> {/* هنا بنقول للمتصفح: اعرضلي مكون App بتاعنا */}
  </React.StrictMode>,
  // وبنعرضه جوه المكان اللي اسمه 'root' في ملف index.html
  document.getElementById('root')
);

